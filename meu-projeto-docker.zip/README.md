# Aplicação Node.js com PostgreSQL usando Docker

## Como usar

1. Copie o arquivo de ambiente:
   cp .env.example .env

2. Suba os containers:
   docker compose up --build

3. Teste:
   http://localhost:3000
   http://localhost:3000/db-test

## Parar containers:
docker compose down
