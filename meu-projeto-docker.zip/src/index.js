const express = require("express");
const { Pool } = require("pg");
require("dotenv").config();

const app = express();
const PORT = process.env.APP_PORT || 3000;

const pool = new Pool({
  host: process.env.DB_HOST,
  port: Number(process.env.DB_PORT || 5432),
  database: process.env.DB_NAME,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD
});

app.get("/", (req, res) => {
  res.json({
    message: "Aplicação rodando com Docker + PostgreSQL",
    status: "ok"
  });
});

app.get("/db-test", async (req, res) => {
  try {
    const result = await pool.query("SELECT NOW() AS agora");
    res.json({
      message: "Conexão com o banco realizada com sucesso",
      database_time: result.rows[0].agora
    });
  } catch (error) {
    res.status(500).json({
      message: "Erro ao conectar no banco",
      error: error.message
    });
  }
});

app.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT}`);
});